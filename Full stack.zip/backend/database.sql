-- database.sql
CREATE DATABASE remote_work;
USE remote_work;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin', 'manager', 'employee') DEFAULT 'employee'
);

CREATE TABLE tasks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(100),
  description TEXT,
  assigned_to INT,
  deadline DATE,
  status ENUM('pending', 'in-progress', 'completed') DEFAULT 'pending',
  FOREIGN KEY (assigned_to) REFERENCES users(id)
);
