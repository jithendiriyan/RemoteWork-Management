const express = require('express');
const router = express.Router();

// Example route: Health check
router.get('/health', (req, res) => {
    res.send({ status: 'API is running smoothly!' });
});

// Example route: Login (placeholder)
router.post('/login', (req, res) => {
    const { username, password } = req.body;

    // Placeholder logic
    if (username === 'admin' && password === 'password') {
        res.send({ success: true, message: 'Login successful' });
    } else {
        res.status(401).send({ success: false, message: 'Invalid credentials' });
    }
});

module.exports = router;
